import collections,re,string,time
bold,underline,red=("\002","\010","\0034")
OrderedDict=collections.OrderedDict
capitalise,join,replace=(string.capitalize,str.join,str.replace,)
split,strip=(str.split,str.strip)
fileName="./resources/<n>.properties"
versionD=OrderedDict()
vn=replace(fileName,"<n>","BibleVersions")
with open(vn,"r") as versionsFile:
	for line in versionsFile:
		k,n=split(line,"=")
		n=replace(replace(n,"\r",""),"\n","")
		versionD[k]=n
#
versions={}
#
sn=replace(fileName,"<n>","USABritishSpellingConversion")
spellingD=OrderedDict()
with open(sn,"r") as spellings:
	for line in spellings:
		k,n=split(line,"=")
		n=replace(replace(n,"\r",""),"\n","")
		spellingD[k]=n
def getVersion(version):
	bv=OrderedDict()
	bn=replace(fileName,"<n>",strip(version))
	try:
		with open(bn,"r") as properties:
			for line in properties:
				v=split(line,"=",1)
				k=strip(v[0])
				t=replace(v[1],"\r","")
				t=replace(t,"\n","")
				bv[k]=strip(t)
			return bv
	except:
		bv["error"]="I could not find version "+bold+version+bold
		return bv 
# get versions 
for vn in versionD:
	print ">>>"+vn+" being processed"
	v=getVersion(vn)
	#correct spellings
	for s in spellingD:
		p1=re.compile(r"\b"+s+r"\b")
		p2=re.compile(r"\b"+capitalise(s)+r"\b")
		r=spellingD[s]
		for k in v:
			t=v[k]
			t=re.sub(p1,r,t,0)
			t=re.sub(p2,capitalise(r),t,0)
			v[k]=t
	with open(vn+".properties","w") as properties:
		for k in v:
			properties.write(k+"="+v[k]+"\r\n")
#'''